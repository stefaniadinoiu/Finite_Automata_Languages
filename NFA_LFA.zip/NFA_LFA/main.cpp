#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;

ifstream f("NFA.in");
ofstream g("NFA.out");

int x, y, z, a[101][101][101], final_s[101], nr, n, ok;
char t, word[101], st[101];

void NFA ( int initial, char word[101], int k)
{
  /* - initial represents an integer, the initial form of the AFN
     - k represents an integer, the stack's position
     - word represents a char, the entrance alphabet*/

  char x = word[0];

  if (final_s[initial] && strlen(word) == 0)
  {
    ok = 1;
    g << " WORD WAS ACCEPTED ";

    return;
  }

  if (strlen(word) != 0 && ok == 0) /* if there still are letters
& it is not known if the word was accepted or not*/

    for (int i = 0; i < n; i++)

      if (a[initial][i][x-'a'])
        {
          st[k] = x;

          strcpy(word, word + 1);
          NFA(i, word, k + 1);

         for (int j = strlen(word); j >= 1; j--)
 /* restore the word if one of the paths doesn't work for it
 and goes back with one position checking for an eventual other path*/
          word[j] = word[j-1];

          word[0] = st[k];
        }
}




int main()
{
    f >> x >> n; // x = number of transitions, n = nr of states

  for (int i = 0; i < x; i++)
  {
    f >> y >> z >> t;         // the transition (qy,t) = qz;

    a[y][z][t-'a'] = 1;
  }

  f >> nr;                  // nr = number of final states

  for (int i = 0; i < nr; i++)
  {
    f >> y;               //y = final states indices

    final_s[y] = 1;
  }

  f >> word;          // the given word

  NFA(0, word, 0);

  if (ok == 0)

  g << " WORD WAS NOT ACCEPTED ";

    return 0;
}

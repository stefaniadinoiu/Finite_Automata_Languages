#include <iostream>
#include "NFA_DFA.h"

using namespace std;


void Project()
{
    cout << "-------- PROJECT II. SUBJECT NFA to DFA ----------\n";
    cout << "----------- DINOIU NADIA STEFANIA ---------\n";
    cout << "------------------ GROUP 211 --------------\n";
}

int main()
{

    Project();

    NFA_DFA Automata;

    Automata.Create_NFA();
    Automata.Display_NFA();
    Automata.Create_DFA();
    Automata.Display_DFA();

    return 0;
}

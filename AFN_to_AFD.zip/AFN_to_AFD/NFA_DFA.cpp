#include <iostream>
#include <fstream>
#include <cstring>
#include "NFA_DFA.h"

using namespace std;

ifstream f("nfa_dfa.in");

///matrix creating method for NFA
void NFA_DFA::Create_NFA()
{

    f >> initial_state;                            /// reading the initial state
    f >> nr_final_sts;                             /// reading the number of final states of the NFA

    for (int i = 0 ; i < nr_final_sts ; i++)       /// reading the actual final states
        f >> Final_States[i];

    f >> nr_letters;                               /// reading the number of letter the alphabet has
    for (int i = 0 ; i < nr_letters ; i++)         /// reads the actual letters
        f >> Letter[i];

    f >> nr_states;                                /// number of states (all)


    for (int i = 0 ; i < nr_states ; i++)
        for (int j = 0 ; j < nr_letters ; j++)
            ///all the elements of the matrix are initialized with -1
            NFA[i][j][0] = -1;

    f >> nr_transitions;                              /// reading the number of transitions

    for (int i = 0 ; i < nr_transitions ; i++)
    {
        f >> q1 >> ltr >> q2;                         /// reading the actual transition (q1,ltr) -> q2

        int ctr = 0;                                  /// final state counter

        while (NFA[q1][ltr-'a'][ctr] != -1)
              ctr++;

        NFA[q1][ltr-'a'][ctr] = q2;
        NFA[q1][ltr-'a'][ctr+1] = -1;
    }
}

///method for displaying NFA's adjacency list

void NFA_DFA::Display_NFA()
{


    cout << "\nGiven NFA: \n\n";

    for (int i = 0 ; i < nr_states ; i++)
    {
        cout << "state " << i << " goes WITH ";
        for (int j = 0 ; j < nr_letters ; j++)
        {
            cout <<"\n letter " << Letter[j] << ", TO state ";

            int ok = 0;

            for (int k = 0 ; NFA[i][j][k] != -1 ; k++)
                cout << NFA[i][j][k], ok = 1;

            if (ok == 0)
                cout << " ** NONE ** ";
        }
        cout << "\n\n";
    }
    cout << "------------- END OF THE NFA -------------\n";
}


/*verifying method for adding a state:
verify if the state that is to be New_State already exists

more specific: TRUE means it already EXISTS,
               FALSE means it does NOT EXIST*/

bool NFA_DFA::Verify_State(int Ste[])
{
    int i, k;

    for (i = 0 ; i < nr_add_sts ; i++)
    {
        k = 0;
      while (DFA[i][nr_letters][k] != -1 && Ste[k] != -1 && DFA[i][nr_letters][k] == Ste[k])
            k++;

        if (Ste[k] == -1 && DFA[i][nr_letters][k] == -1)
            return true;

    }
    return false;
}

/*method - that is gonna help later in adding
new states into the DFA*/
void NFA_DFA::Sort_Sts_Delete_AlikeSts(int v[], int n)
{
    int i, j;

    for (i = 0 ; i < n-1 ; i++)
        for (j = i+1 ; j < n ; j++)
            if (v[i] > v[j])
                swap(v[i],v[j]);

    for (i = 0 ; i < n-1 ; i++)
        if (v[i] == v[i+1])
        {
            for(j = i+1 ; j < n ; j++)
                v[j] = v[j+1];
            n--;
        }
}

/*method for adding states
putting the column for the states at the end */

void NFA_DFA::Add_State(int New_State[])
{
    int i, j, k, m;

    if (Verify_State(New_State) == false)
    {
        for (i = 0 ; New_State[i] != -1 ; i++)
            DFA[nr_add_sts][nr_letters][i] = New_State[i];

        DFA[nr_add_sts][nr_letters][i] = -1;

        for (i = 0; i < nr_letters ; i++)
        {
            m = 0;

            for (j = 0; New_State[j] != -1 ; j++)
                for (k = 0; NFA[New_State[j]][i][k] != -1 ; k++)
                    DFA[nr_add_sts][i][m++] = NFA[New_State[j]][i][k];

            DFA[nr_add_sts][i][m] = -1;
            Sort_Sts_Delete_AlikeSts (DFA[nr_add_sts][i], m);
        }

        nr_add_sts++;
    }
}

///matrix creating method for DFA

void NFA_DFA::Create_DFA()
{
    int v[2];
    v[0] = initial_state;
    v[1] = -1;

    nr_add_sts = 0;                     ///adding the initial state of the DFA

    Add_State(v);

    int i = 0;

    while (i < nr_add_sts)
    {
        for (int j = 0; j < nr_letters ; j++)
            if (DFA[i][j][0] != -1)
                Add_State(DFA[i][j]);
        i++;
    }

    int k, ltr, q;

    nr_states1 = 0;                                            ///DFA states counter
    for (i = 0; i < nr_add_sts; i++)
        for (k = 0; DFA[i][nr_letters][k] != -1; k++)
            for (ltr = 0; ltr < nr_final_sts; ltr++)
                if (Final_States[ltr] == DFA[i][nr_letters][k])
                {
                    for (q = 0; DFA[i][nr_letters][q] != -1; q++)
                    FIN[nr_states1][q] = DFA[i][nr_letters][q];
                    FIN[nr_states1][q] = -1;
                    nr_states1++;
                }
}

///method for displaying DFA's adjacency list
void NFA_DFA::Display_DFA()
{
    int i, j, k;

    cout << "\nCorrespondent DFA : " << " \n\n";

    for (i = 0; i < nr_add_sts; i++)
    {
        cout << "state ";

        for (k = 0; DFA[i][nr_letters][k] != -1; k++)
            cout<<DFA[i][nr_letters][k];

        cout << " goes with ";

        for (j = 0; j < nr_letters ; j++)
        {
            cout << "\n letter " << Letter[j] << " to ";

            int ok = 0;

            for (k = 0; DFA[i][j][k] != -1; k++)
                ok = 1, cout << DFA[i][j][k];

            if (ok == 0)
                cout << " ** NONE ** ";
        }
        cout << "\n\n";

    }

    cout<<"\n\n DFA final states are: \n\n ";

    for (i = 0; i < nr_states1; i++)
    {
        for (int j = 0 ; FIN[i][j] != -1 ; j++)
            cout << FIN[i][j];

        if (i < nr_states1 - 1)
            cout << ", ";
    }

    cout << "\n" << "------------- END OF DFA -------------" << "\n";
}

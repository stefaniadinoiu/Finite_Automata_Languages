#ifndef NFA_DFA_H_INCLUDED
#define NFA_DFA_H_INCLUDED

class NFA_DFA
{
public:

    NFA_DFA() {}                  // constructor and destructor
    virtual ~NFA_DFA() {}


    // variables

    int nr_states;                // number of states NFA
    int initial_state;            // initial state
    int nr_transitions;           // number of transitions for NFA
    int q1, q2;                   // state_1, state_2 from a transition
    char ltr;                     // transition letter
    int nr_letters;               // number of letter from the given alphabet
    int nr_final_sts;             // number of FINAL states NFA
    int nr_add_sts;               // number of ADDED states
    int nr_states1;               // number of states DFA
    int Final_States[25];         // ACTUAL final states NFA
    int FIN[25][25];              // ACTUAL final states DFA
    char Letter[10];              // alphabet
    int NFA[25][25][25];          // NFA matrix
    int DFA[25][25][25];          // DFA matrix

    //used methods

    void Create_NFA();
    void Display_NFA();
    bool Verify_State(int*);
    void Sort_Sts_Delete_AlikeSts(int*, int);
    void Add_State(int*);
    void Create_DFA();
    void Display_DFA();
};


#endif // NFA_DFA_H_INCLUDED
